#pragma once


//解决tcp粘包问题的消息头
struct msg_head
{
    int msgid;
    int msglen;
};

//消息头的二进制长度
#define MSG_HEAD_LEN 8

//消息体的最大长度限制(消息头+消息体最长为65535个字节)
#define MSG_LEN_LIMIT (65535 - MSG_HEAD_LEN)