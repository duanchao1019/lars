#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "tcp_server.h"
#include "reactor_buf.h"


struct message
{
    char data[m4K];
    char len;
};

struct message msg;

void server_rd_callback(event_loop* loop, int fd, void* args);
void server_wt_callback(event_loop* loop, int fd, void* args);


void accept_callback(event_loop* loop, int fd, void* args)
{
    tcp_server* server = (tcp_server *)args;
    server->do_accept();
}


tcp_server::tcp_server(const char *ip, uint16_t port, event_loop* loop)
: loop_(loop)
{
    //0. 忽略信号
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR)
    {
        fprintf(stderr, "ignore signal SIGHUP error\n");
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    {
        fprintf(stderr, "ignore signal SIGPIPE error\n");
    }

    //1. 创建套接字
    if ((sockfd_ = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        fprintf(stderr, "create sockfd_ error\n");
        exit(1);
    }

    //2. 初始化服务器地址
    struct sockaddr_in server_addr;
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_pton(AF_INET, ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);

    //2.5 设置端口复用
    int opt = 1;
    if (setsockopt(sockfd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        fprintf(stderr, "setsockopt sockfd_ reuseaddr error\n");
    }

    //3. 绑定端口
    if (bind(sockfd_, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "bind sockfd_ to server_addr error\n");
        exit(1);
    }

    //4. 监听
    if (listen(sockfd_, 500) < 0)
    {
        fprintf(stderr, "listen sockfd_ error\n");
        exit(1);
    }

    //5. 注册sockfd_读事件
    loop_->add_io_event(sockfd_, accept_callback, EPOLLIN, this);
}


void server_rd_callback(event_loop* loop, int fd, void* args)
{
    int ret = 0;

    struct message* msg = (struct message *)args;
    input_buf ibuf;

    ret = ibuf.read_data(fd);
    if (ret == -1)
    {
        fprintf(stderr, "ibuf read_data error\n");
        loop->del_io_event(fd);
        close(fd);
        return;
    }
    if (ret == 0)
    {
        loop->del_io_event(fd);
        close(fd);
        return;
    }

    printf("ibuf.length() = %d\n", ibuf.length());

    msg->len = ibuf.length();
    bzero(msg->data, msg->len);
    memcpy(msg->data, ibuf.data(), msg->len);

    ibuf.pop(msg->len);
    ibuf.adjust();

    printf("receive data = %s\n", msg->data);

    //删除读事件，添加写事件
    loop->del_io_event(fd, EPOLLIN);
    loop->add_io_event(fd, server_wt_callback, EPOLLOUT, msg);
}

void server_wt_callback(event_loop* loop, int fd, void* args)
{
    struct message* msg = (struct message *)args;
    output_buf obuf;

    //回显数据
    obuf.send_data(msg->data, msg->len);
    while (obuf.length())
    {
        int write_ret = obuf.write2fd(fd);
        if (write_ret == -1)
        {
            fprintf(stderr, "write connfd error\n");
            return;
        }
        else if (write_ret == 0)
        {
            //不是错误，表示此时不可写
            break;
        }
    }

    //删除写事件，添加读事件
    loop->del_io_event(fd, EPOLLOUT);
    loop->add_io_event(fd, server_rd_callback, EPOLLIN, msg);
}

void tcp_server::do_accept()
{
    int connfd;
    while (true)
    {
        connfd = accept(sockfd_, (struct sockaddr *)&client_addr_, &client_addr_len_);
        if (connfd == -1)
        {
            if (errno == EINTR)        //中断错误，属于正常errno，
                continue;
            else if (errno == EMFILE)  //连接建立过多，文件描述符资源不够用了
            {
                fprintf(stderr, "too many connections\n");
                continue;
            }
            else if (errno == EAGAIN || errno == EWOULDBLOCK)  //套接字为非阻塞时产生的正常errno
            {
                printf("would block\n");
                continue;
            }
            else  //发生其他错误，则中止程序
            {
                fprintf(stderr, "accept error\n");
                exit(1);
            }
        }
        else
        {
            this->loop_->add_io_event(connfd, server_rd_callback, EPOLLIN, &msg);
            break;
        }
    }
}

tcp_server::~tcp_server()
{
    close(sockfd_);
}