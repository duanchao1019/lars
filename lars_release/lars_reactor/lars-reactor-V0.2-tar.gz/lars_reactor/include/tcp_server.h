#pragma once

#include <netinet/in.h>


class tcp_server
{
public:
    tcp_server(const char *ip, uint16_t port);

    void do_accept();

    ~tcp_server();

private:
    int sockfd_;   //listenfd;
    struct sockaddr_in client_addr_;
    socklen_t client_addr_len_;
};