#include <iostream>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>
#include <signal.h>
#include <errno.h>
#include <arpa/inet.h>
#include <sys/types.h>
#include <sys/socket.h>

#include "tcp_server.h"
#include "reactor_buf.h"

tcp_server::tcp_server(const char *ip, uint16_t port)
{
    //0. 忽略信号
    if (signal(SIGHUP, SIG_IGN) == SIG_ERR)
    {
        fprintf(stderr, "ignore signal SIGHUP error\n");
    }
    if (signal(SIGPIPE, SIG_IGN) == SIG_ERR)
    {
        fprintf(stderr, "ignore signal SIGPIPE error\n");
    }

    //1. 创建套接字
    if ((sockfd_ = socket(AF_INET, SOCK_STREAM, 0)) < 0)
    {
        fprintf(stderr, "create sockfd_ error\n");
        exit(1);
    }

    //2. 初始化服务器地址
    struct sockaddr_in server_addr;
    bzero(&server_addr, sizeof(server_addr));
    server_addr.sin_family = AF_INET;
    inet_pton(AF_INET, ip, &server_addr.sin_addr);
    server_addr.sin_port = htons(port);

    //2.5 设置端口复用
    int opt = 1;
    if (setsockopt(sockfd_, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt)) < 0)
    {
        fprintf(stderr, "setsockopt sockfd_ reuseaddr error\n");
    }

    //3. 绑定端口
    if (bind(sockfd_, (struct sockaddr *)&server_addr, sizeof(server_addr)) < 0)
    {
        fprintf(stderr, "bind sockfd_ to server_addr error\n");
        exit(1);
    }

    //4. 监听
    if (listen(sockfd_, 500) < 0)
    {
        fprintf(stderr, "listen sockfd_ error\n");
        exit(1);
    }
}

void tcp_server::do_accept()
{
    int connfd;
    while (true)
    {
        printf("start accept\n");
        connfd = accept(sockfd_, (struct sockaddr *)&client_addr_, &client_addr_len_);
        if (connfd == -1)
        {
            if (errno == EINTR)        //中断错误，属于正常errno，
                continue;
            else if (errno == EMFILE)  //连接建立过多，文件描述符资源不够用了
            {
                fprintf(stderr, "too many connections\n");
                continue;
            }
            else if (errno == EAGAIN || errno == EWOULDBLOCK)  //套接字为非阻塞时产生的正常errno
            {
                printf("would block\n");
                continue;
            }
            else  //发生其他错误，则中止程序
            {
                fprintf(stderr, "accept error\n");
                exit(1);
            }
        }
        else
        {
            int ret = 0;
            input_buf ibuf;
            output_buf obuf;

            char* msg = nullptr;
            int msg_len = 0;

            do {
                ret = ibuf.read_data(connfd);
                if (ret == -1)
                {
                    fprintf(stderr, "ibuf read_data error\n");
                    break;
                }
                printf("ibuf.length() = %d\n", ibuf.length());

                //将读到的数据放在msg中
                msg_len = ibuf.length();
                msg = (char *)malloc(msg_len);
                bzero(msg, msg_len);
                memcpy(msg, ibuf.data(), msg_len);
                ibuf.pop(msg_len);
                ibuf.adjust();

                printf("receive data = %s\n", msg);

                //回显数据
                if (obuf.send_data(msg, msg_len) == 0)
                {
                    while (obuf.length())
                    {
                        int write_ret = obuf.write2fd(connfd);
                        if (write_ret == -1)
                        {
                            fprintf(stderr, "write connfd error\n");
                            return;
                        }
                        else if (write_ret == 0)
                        {
                            //不是错误，只是表示此时不可写
                            break;
                        }
                    }

                    free(msg);
                }
                else
                {
                    fprintf(stderr, "obuf send_data error\n");
                    break;
                }

            } while (ret != 0);

            close(connfd);
        }
    }
}

tcp_server::~tcp_server()
{
    close(sockfd_);
}