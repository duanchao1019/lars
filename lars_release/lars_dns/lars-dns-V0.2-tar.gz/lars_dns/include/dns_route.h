#pragma once

#include <pthread.h>
#include <unordered_map>
#include <unordered_set>
#include "mysql.h"
#include "lars_reactor.h"

typedef std::unordered_set<uint64_t> host_set;
typedef std::unordered_set<uint64_t>::iterator host_set_it;

typedef std::unordered_map<uint64_t, host_set> route_map;
typedef std::unordered_map<uint64_t, host_set>::iterator route_map_it;

class Route
{
public:
    static void init()
    {
        instance_ = new Route();
    }

    static Route* instance()
    {
        pthread_once(&once_, init);
        return instance_;
    }

    void connect_db();

    void build_maps();

    host_set get_hosts(int modid, int cmdid);

private:
    Route();
    Route(const Route&);
    Route& operator=(const Route&);

private:
    static Route* instance_;
    static pthread_once_t once_;  //单例锁，确保init函数只执行一次

    MYSQL db_conn_;  //mysql连接
    char sql_[1000]; //sql语句

    route_map* data_pointer_;  //指向RouteDataMap_A，当前的关系map
    route_map* temp_pointer_;  //指向RouteDataMap_B，临时的关系map

    pthread_rwlock_t map_lock_;
};