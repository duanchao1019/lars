#include "dns_route.h"
#include <string>
#include <string.h>
using std::string;

Route* Route::instance_ = NULL;
pthread_once_t Route::once_ = PTHREAD_ONCE_INIT;


Route::Route()
{
    pthread_rwlock_init(&map_lock_, NULL);

    data_pointer_ = new route_map();
    temp_pointer_ = new route_map();

    this->connect_db();

    this->build_maps();
}

void Route::connect_db()
{
    //mysql数据库配置
    string db_host = config_file::instance()->GetString("mysql", "db_host", "127.0.0.1");
    uint16_t db_port = config_file::instance()->GetNumber("mysql", "db_port", 3306);
    string db_user = config_file::instance()->GetString("mysql", "db_user", "root");
    string db_passwd = config_file::instance()->GetString("mysql", "db_passwd", "971019");
    string db_name = config_file::instance()->GetString("mysql", "db_name", "lars_dns");

    if (mysql_init(&db_conn_) == NULL)
    {
        fprintf(stderr, "mysql_init error\n");
        exit(1);
    }

    //超时断开
    mysql_options(&db_conn_, MYSQL_OPT_CONNECT_TIMEOUT, "30");
    //设置mysql连接断开后自动重连
    char reconnect = 1;
    mysql_options(&db_conn_, MYSQL_OPT_RECONNECT, &reconnect);

    if (!mysql_real_connect(&db_conn_, db_host.c_str(), db_user.c_str(), db_passwd.c_str(), db_name.c_str(), db_port, NULL, 0))
    {
        fprintf(stderr, "Failed to connect mysql, error: %s\n", mysql_error(&db_conn_));
        exit(1);
    }   
}

void Route::build_maps()
{
    int ret = 0;

    snprintf(sql_, 1000, "SELECT * FROM RouteData;");
    ret = mysql_real_query(&db_conn_, sql_, strlen(sql_));
    if (ret != 0)
    {
        fprintf(stderr, "Failed to find any data, error %s\n", mysql_error(&db_conn_));
        exit(1);
    }

    //得到结果集
    MYSQL_RES* result = mysql_store_result(&db_conn_);

    //得到行数
    uint32_t line_num = mysql_num_rows(result);

    MYSQL_ROW row;
    for (uint32_t i = 0; i < line_num; i++)
    {
        row = mysql_fetch_row(result);
        int modId = atoi(row[1]);
        int cmdId = atoi(row[2]);
        unsigned ip = atoi(row[3]);
        int port = atoi(row[4]);

        //组装map的key，由modId/cmdId组合
        uint64_t key = ((uint64_t)modId << 32) + cmdId;
        uint64_t value = ((uint64_t)ip << 32) + port;

        printf("modId = %d, cmdId = %d, ip = %u, port = %d\n", modId, cmdId, ip, port);

        //插入到RouteDataMap_A中
        (*data_pointer_)[key].insert(value);
    }

    mysql_free_result(result); //释放结果集
}

host_set Route::get_hosts(int modid, int cmdid)
{
    host_set hosts;

    //组装key
    uint64_t key = ((uint64_t)modid << 32) + cmdid;
    
    //加读锁
    pthread_rwlock_rdlock(&map_lock_);
    if (data_pointer_->find(key) != data_pointer_->end())
    {
        //找到了对应的ip+host对
        hosts = (*data_pointer_)[key];
    }
    pthread_rwlock_unlock(&map_lock_);

    return hosts;
}